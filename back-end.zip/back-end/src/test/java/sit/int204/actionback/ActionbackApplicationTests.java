package sit.int204.actionback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActionbackApplicationTests {

    @Test
    void contextLoads() {
    }

}
