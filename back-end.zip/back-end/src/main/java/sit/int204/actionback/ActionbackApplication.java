package sit.int204.actionback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActionbackApplication {
    public static void main(String[] args) {
        SpringApplication.run(ActionbackApplication.class, args);
    }


}
